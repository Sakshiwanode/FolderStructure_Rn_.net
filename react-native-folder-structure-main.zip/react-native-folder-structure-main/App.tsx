import React, {useEffect, useState} from 'react';
import 'react-native-gesture-handler';
import {NavigationContainer} from '@react-navigation/native';
import {Provider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
import {persistor, store} from './src/AppStore/Store/store';
import {SafeAreaView} from 'react-native';
import {PaperProvider} from 'react-native-paper';
import DrawerNavigator from './src/AppNavigator/DrawerNavigator';
import NetInfo from '@react-native-community/netinfo';
import Toast from 'react-native-toast-message';

const App = () => {
  const [isConnected, setIsConnected] = useState(null);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state: any) => {
      setIsConnected(state.isConnected);
      showToast(state.isConnected);
    });

    return () => unsubscribe();
  }, [isConnected]);

  const showToast = (connected: any) => {
    Toast.show({
      type: connected ? 'success' : 'error',
      text1: connected ? 'Online' : 'Offline',
      text2: connected
        ? 'You are now connected to the internet.'
        : 'You are currently offline.',
    });
  };

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <PaperProvider>
          <SafeAreaView style={{flex: 1}}>
            <NavigationContainer>
              <DrawerNavigator />
            </NavigationContainer>
          </SafeAreaView>
          <Toast />
        </PaperProvider>
      </PersistGate>
    </Provider>
  );
};

export default App;
