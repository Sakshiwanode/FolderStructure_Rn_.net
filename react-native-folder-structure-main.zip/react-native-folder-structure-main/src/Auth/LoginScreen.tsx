import {View, TextInput, Alert} from 'react-native';
import React, {useState} from 'react';
import {useDispatch} from 'react-redux';
import {first} from '../AppStore/Reducers/DemoSlice';
import CustomButton from '../Components/CustomButton';

const LoginScreen = ({}: any) => {
  const dispatch = useDispatch();
  const [text, setText] = useState('');

  const handlePress = () => {
    dispatch(first(text));

    Alert.alert('Data save successfully, Check on home screen!');
  };

  return (
    <View style={{flex: 1, justifyContent: 'center'}}>
      <View style={{justifyContent: 'center', alignItems: 'center'}}>
        <TextInput
          placeholder="Enter something..."
          value={text}
          onChangeText={(txt: any) => {
            setText(txt);
          }}
          style={{
            width: '90%',
            height: 40,
            borderWidth: 2,
            borderColor: '#000',
            borderRadius: 8,
            marginVertical: 20,
          }}
        />
      </View>

      <CustomButton
        title={'Save'}
        icon="content-save-check"
        onPress={() => {
          handlePress();
        }}
      />
    </View>
  );
};

export default LoginScreen;
