import {View, Text} from 'react-native';
import React from 'react';
import {useSelector} from 'react-redux';
import TailwindDemo from './tailwindDemo';

const HomeScreen = () => {
  return (
    <View
      style={{
        flex: 1,
      }}>
      <TailwindDemo />
    </View>
  );
};

export default HomeScreen;
