import React from 'react';
import {Text, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import CustomButton from '../Components/CustomButton';
import {first} from '../AppStore/Reducers/DemoSlice';

const TailwindDemo = () => {
  const dispatch = useDispatch();
  const data = useSelector((state: any) => state?.demo?.value);

  return (
    <View className="bg-yellow-500 w-full h-full">
      <Text className="text-black justify-center text-sm text-center m-5">
        This data is comes from redux store !
      </Text>
      <Text className="text-blue-500 text-3xl justify-center text-center mb-96">
        {data?.length ? <Text>{data}</Text> : <Text>No save data !</Text>}
      </Text>
      <CustomButton
        title={'Clear Data'}
        icon="select-remove"
        onPress={() => {
          dispatch(first(''));
        }}
      />
    </View>
  );
};

export default TailwindDemo;
