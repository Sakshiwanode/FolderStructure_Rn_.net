import * as React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import HomeScreen from '../Screens/HomeScreen';
import SignUpScreen from '../Auth/SignUpScreen';
import StackNavigator from './StackNavigator';
import {Icon} from 'react-native-paper';

const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#285caa',
        tabBarStyle: [
          {
            display: 'flex',
            backgroundColor: '#fff',
          },
          null,
        ],
      }}>
      <Tab.Screen
        name="LogIn"
        component={StackNavigator}
        options={{
          headerShown: false,
          tabBarIcon: ({size, color}) => (
            <Icon source={'bike'} color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="SignUp"
        component={SignUpScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({size, color}) => (
            <Icon source={'car'} color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({size, color}) => (
            <Icon source={'home'} color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};

export default BottomTabNavigator;
