import {createApi} from '@reduxjs/toolkit/query/react';
import axios from 'axios';

const axiosBaseQuery = (baseUrl: any) => async (payload: any) => {
  try {
    const result = await axios({
      url: baseUrl?.baseUrl + payload?.url,
      method: payload?.method,
      data: payload?.body,
      headers: payload?.headers,
    });
    return {data: result?.data};
  } catch (axiosError) {
    const err: any = axiosError;
    return {
      error: {
        status: err?.response?.status,
        data: err?.response?.data || err?.message,
      },
    };
  }
};

export const services = createApi({
  reducerPath: 'parsApi',
  baseQuery: axiosBaseQuery({baseUrl: 'https://uatapi.queensford.edu.au/api'}),
  endpoints: builder => ({
    userAuthenticationlogin: builder.mutation({
      query: data => ({
        url: `/Auth/UserAuthentication`,
        method: 'POST',
        body: data,
      }),
    }),

    GetListOfStudentCourses: builder.query({
      query: data => ({
        url: `/Student/GetListOfStudentCourses/?${data.id}&${data.module}`,
        method: 'GET',
        headers: {
          Authorization: `Bearer ${data.accessToken}`,
        },
      }),
    }),
  }),
});

export const {
  useGetListOfStudentCoursesQuery,
  useUserAuthenticationloginMutation,
} = services;
