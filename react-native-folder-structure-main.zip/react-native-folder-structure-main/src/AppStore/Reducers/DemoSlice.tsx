import {createSlice} from '@reduxjs/toolkit';

export const demoSlice = createSlice({
  name: 'demo',
  initialState: {
    value: null,
  },
  reducers: {
    first: (state, action) => {
      state.value = action.payload;
    },
  },
});

export const {first} = demoSlice.actions;

export default demoSlice.reducer;
